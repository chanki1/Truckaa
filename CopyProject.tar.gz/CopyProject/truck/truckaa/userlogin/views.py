from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import Username
from django.contrib.auth.decorators import login_required

# Create your views here.
# Implement Class based views, Current is Generic based view.
# Generic  Views  (https://docs.djangoproject.com/en/1.5/topics/class-based-views/generic-display/)
# have  always provided some basic functionality: render a template, redirect, create or edit a model, etc

def signup(request):
    # Get or edit from models HERE
    username = "chankigogia@gmail.com" #User.last_login_at
    last_log = '00:00:00:00:0000'
    context = {'user': username,'timestmp':last_log}
    return render(request, 'userlogin/signup.html', context)

#@login_required(login_url="r'[a-zA-Z0-9._+-]+")
def welcome(request):
    #User.username = username
    #get_object_or_404(Username,pk=username)
    #context = {'usr': 'chankigogia'}
    return render(request, 'userlogin/welcome.html')


def forgotusername(request, username):
    context = {'usr': username}
    return render(request, 'userlogin/forgotusername.html', context)