from django import forms
from django.core.exceptions import ValidationError

from userlogin.models import Username

class UserEmailForm(forms.ModelForm):
    confirm_email = forms.EmailField(label="Confirm Email",required=True,)

    class Meta:
        model= Username

    def __init__(self,*args,**kwargs):

        if kwargs.get('instance'):
            email = kwargs['instance'].email
            kwargs.setdefault('initial', {})['confirm_email'] = email

        return super(UserEmailForm, self).__init__(*args, **kwargs)
