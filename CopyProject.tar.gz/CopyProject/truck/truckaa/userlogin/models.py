from django.db import models
class Username(models.Model):
    username = models.TextField('emailORUsername', max_length=100, blank=False)
    associated_email = models.EmailField('emailId', max_length= 100)
    last_login_at=models.TimeField(blank=True)
    def __str__(self):
        return self.username
    # Create your models here.
class Password(models.Model):
    password = models.CharField(max_length=100, help_text="password")