from django.contrib import admin

from .models import Username

admin.site.register(Username)

# Register your models here.
