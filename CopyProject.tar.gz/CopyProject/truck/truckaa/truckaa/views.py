from django.shortcuts import render
from django.http import HttpResponse
from .models import Username

# Create your views here.
# Implement Class based views, Current is Generic based view.
# Generic  Views  (https://docs.djangoproject.com/en/1.5/topics/class-based-views/generic-display/)
# have  always provided some basic functionality: render a template, redirect, create or edit a model, etc

def signup(request):
    # Get or edit from models HERE
    username = "chankigogia@gmail.com" #User.last_login_at
    last_log = '00:00:00:00:0000'
    context = {'user': username,'timestmp':last_log}
    return render(request, 'userlogin/signup.html', context)


def welcome(request, username):
    #User.username = username

    context = {'usr': username}
    return render(request, 'userlogin/welcome.html', context)

def forgotusername(request, username):
    context = {'usr': username}
    return render(request, 'userlogin/forgotusername.html', context)