from django.db import models

class Driver(models.Model):

    drivername = models.TextField('emailORUsername', max_length=100, blank=False)
    email = models.EmailField('emailId', max_length= 100)
    last_login_at = models.TimeField(blank=True)
    #online_status = models.NullBooleanField(default=False)
    online_choices = (
        ('2','offline'),
        ('3','online'),
    )
    online_status = models.CharField(choices=online_choices,max_length=1)
    primary_location = models.TextField(blank=False)
    current_location = models.TextField(blank=False)

    def onlinecheck(self):
        Driver.objects.get(online_status__in='false')

# booking confirmation da data save karn lyi v table chahida

class Truck(models.Model):
    driver = models.ForeignKey('Driver')
    number = models.TextField(max_length=12)
    model = models.CharField(max_length=200)
    capacity = models.IntegerField()
    chasi_numer = models.IntegerField()


