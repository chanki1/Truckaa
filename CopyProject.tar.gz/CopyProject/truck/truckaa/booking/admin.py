from django.contrib import admin

from .models import Driver

admin.site.register(Driver)
# Register your models here.
