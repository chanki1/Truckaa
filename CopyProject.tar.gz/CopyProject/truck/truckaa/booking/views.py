from builtins import type

from django.shortcuts import render
from .models import Driver,Truck
from django.db.models import Q
#Think this as your backend
# Create your views here.
def booking(request):
    #User.username = username
    #get_object_or_404(Username,pk=username)
    #context = {'usr': 'chankigogia'}
    return render(request, 'booking/booktruck.html')

def bookingConfirmation(request):
    #get which driver is having online status true and driver details who picks up the ride
    Driverobj = Driver.objects.filter(Q(online_status=3),Q(current_location__contains='Delhi'))
    u = Driverobj.values()[0]
    context = {'usr': u}
    return render(request, 'booking/bookingConfirmation.html',context)


